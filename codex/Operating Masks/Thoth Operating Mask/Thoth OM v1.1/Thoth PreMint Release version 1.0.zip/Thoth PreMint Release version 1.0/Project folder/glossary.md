# memory/glossary.md
- OM: Operating Mask (structural pipeline)
- Mirror residual: normalized distortion score after trims
- SC@k: self-consistency with k candidates
- Crown Verify: final ship gate (checks + next action)
