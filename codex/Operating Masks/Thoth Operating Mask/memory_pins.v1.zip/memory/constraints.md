# memory/constraints.md
- No zips unless explicitly requested
- Cite sources only in Tier 3 runs
- All outputs end with one concrete next action
