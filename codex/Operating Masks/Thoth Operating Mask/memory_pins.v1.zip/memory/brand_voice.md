# memory/brand_voice.md
- Tone: grounded, confident, concise
- Word economy: prefer verbs over adjectives
- Allow "resonance" once per artifact, ban hype terms
- Avoid mystic labels; describe mechanisms
