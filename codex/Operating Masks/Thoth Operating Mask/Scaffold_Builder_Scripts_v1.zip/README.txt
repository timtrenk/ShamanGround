Scaffold Builder Scripts — v1.0.0

Pick one path:
- Upload to chat:  chat_upload/scaffold_spec.yaml (then say "build my scaffold")
- Run on any server:  server/scaffold_builder.py  (Python + PyYAML)
- Run on Windows:     windows/scaffold_builder.ps1
- Run on Linux/Mac:   linux_mac/scaffold_builder.sh

All methods read the same scaffold_spec.yaml so results are consistent.
Timestamp: 2025-10-13T21:24:35.138175Z
