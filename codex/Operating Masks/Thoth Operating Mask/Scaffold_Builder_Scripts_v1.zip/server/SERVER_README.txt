Use on any machine with Python 3:
1) Put server/scaffold_builder.py and scaffold_spec.yaml in an empty folder.
2) Install PyYAML once:  pip install pyyaml
3) Run:  python3 server/scaffold_builder.py
4) Outputs: runtime.yaml, memory/, and optional templates/ (if enabled).
