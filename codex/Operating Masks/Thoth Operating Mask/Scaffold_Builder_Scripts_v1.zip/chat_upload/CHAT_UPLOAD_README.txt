CHAT_UPLOAD_README.txt — v1.0.0 (2025-10-13T21:24:35.138175Z)

Use in this chat UI:
1) Upload "scaffold_spec.yaml" into the chat project folder.
2) Say:  build my scaffold
3) I will generate the scaffold inside chat and give you direct download links.

Tip: Edit scaffold_spec.yaml before uploading to change defaults.
