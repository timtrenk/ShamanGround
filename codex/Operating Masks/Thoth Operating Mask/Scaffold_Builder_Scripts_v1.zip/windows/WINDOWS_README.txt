1) Place scaffold_spec.yaml next to this pack.
2) Run: powershell -ExecutionPolicy Bypass -File .\windows\scaffold_builder.ps1
3) Outputs appear beside scaffold_spec.yaml.
