1) Put scaffold_spec.yaml next to this pack.
2) chmod +x linux_mac/scaffold_builder.sh
3) ./linux_mac/scaffold_builder.sh
4) Outputs appear beside scaffold_spec.yaml.
