# Thoth OM v1 — Folder Canon (Flat, no './')
Paste these 4 files into your one-folder project:
- Thoth_OM_v1.yaml
- segmentation_12_nodes.yaml
- segments.schema.json
- segment_to_gates.yaml  (7-gate map)

Run your engine with `Thoth_OM_v1.yaml` as the entrypoint.
Use `diagnostics_profile.yaml` as a quick smoke test spec.
